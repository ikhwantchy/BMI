-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: kopsyah_bmi
-- ------------------------------------------------------
-- Server version	8.0.46-0ubuntu0.24.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_logs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint unsigned DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'create, update, delete, submit, validate, reject, login',
  `entity_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Class name, misal: App\\Models\\Evaluation',
  `entity_id` bigint unsigned DEFAULT NULL,
  `old_values` json DEFAULT NULL,
  `new_values` json DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_logs_entity_type_entity_id_index` (`entity_type`,`entity_id`),
  KEY `audit_logs_user_id_index` (`user_id`),
  KEY `audit_logs_action_index` (`action`),
  KEY `audit_logs_created_at_index` (`created_at`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,1,'login','App\\Models\\User',1,NULL,NULL,'158.140.191.84','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36','2026-10-04 17:42:06','2026-10-04 17:42:06'),(2,1,'login','App\\Models\\User',1,NULL,NULL,'158.140.191.71','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36','2026-10-05 00:17:43','2026-10-05 00:17:43'),(3,1,'login','App\\Models\\User',1,NULL,NULL,'180.250.68.243','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','2026-10-05 02:07:24','2026-10-05 02:07:24'),(4,1,'login','App\\Models\\User',1,NULL,NULL,'114.10.77.151','Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36','2026-10-05 02:34:36','2026-10-05 02:34:36'),(5,1,'login','App\\Models\\User',1,NULL,NULL,'158.140.191.96','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36 Edg/154.0.0.0','2026-10-05 02:43:06','2026-10-05 02:43:06');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `businesses`
--

DROP TABLE IF EXISTS `businesses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `businesses` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `member_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci,
  `business_age_months` smallint unsigned DEFAULT NULL COMMENT 'Lama usaha dalam bulan',
  `initial_capital` bigint unsigned DEFAULT NULL COMMENT 'Modal awal dalam rupiah',
  `products_services` text COLLATE utf8mb4_unicode_ci COMMENT 'Produk/jasa yang dijual',
  `initial_condition` text COLLATE utf8mb4_unicode_ci COMMENT 'Kondisi awal usaha saat bergabung',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `businesses_member_id_index` (`member_id`),
  KEY `businesses_status_index` (`status`),
  CONSTRAINT `businesses_member_id_foreign` FOREIGN KEY (`member_id`) REFERENCES `members` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `businesses`
--

LOCK TABLES `businesses` WRITE;
/*!40000 ALTER TABLE `businesses` DISABLE KEYS */;
INSERT INTO `businesses` VALUES (1,1,'Toko Sembako Berkah Siti','Perdagangan / Kelontong','Pasar Curug Kios No. 14, Tangerang',36,15000000,'Beras, minyak goreng, gula, sembako, dan kebutuhan pokok harian.','Usaha sudah berjalan stabil dengan omset harian rutin Rp 2-3 juta.','active','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(2,2,'Bengkel Motor Fauzi Mandiri','Jasa Otomotif','Jl. Raya Pemda No. 10, Curug',18,10000000,'Servis motor, ganti oli, dan penjualan suku cadang motor.','Pelanggan ramai, memerlukan modal tambahan untuk etalase suku cadang resmi.','active','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(3,3,'Konveksi Hijab Zahra','Industri Rumahan / Tekstil','Perum Griya Asri Blok B2 No. 12',24,8000000,'Jahit jilbab, gamis syari, mukena pesanan reseller.','Memiliki 3 mesin jahit, pasokan kain terkadang tersendat.','active','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(4,4,'Budidaya Lele Sangkuriang','Perikanan / Pertanian','Kp. Dukuh RT 01/RW 04, Balaraja',8,5000000,'Bibit lele dan lele siap konsumsi ke warung pecel lele.','4 kolam terpal, sering terkendala harga pakan pelet fluktuatif.','active','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL);
/*!40000 ALTER TABLE `businesses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coaching_followups`
--

DROP TABLE IF EXISTS `coaching_followups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coaching_followups` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_id` bigint unsigned NOT NULL,
  `recommendation_id` bigint unsigned DEFAULT NULL,
  `followup_date` date NOT NULL,
  `activity` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Kegiatan tindak lanjut yang dilakukan',
  `result` text COLLATE utf8mb4_unicode_ci COMMENT 'Hasil tindak lanjut',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `officer_id` bigint unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coaching_followups_recommendation_id_foreign` (`recommendation_id`),
  KEY `coaching_followups_officer_id_foreign` (`officer_id`),
  KEY `coaching_followups_evaluation_id_index` (`evaluation_id`),
  CONSTRAINT `coaching_followups_evaluation_id_foreign` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coaching_followups_officer_id_foreign` FOREIGN KEY (`officer_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `coaching_followups_recommendation_id_foreign` FOREIGN KEY (`recommendation_id`) REFERENCES `coaching_recommendations` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coaching_followups`
--

LOCK TABLES `coaching_followups` WRITE;
/*!40000 ALTER TABLE `coaching_followups` DISABLE KEYS */;
/*!40000 ALTER TABLE `coaching_followups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coaching_recommendations`
--

DROP TABLE IF EXISTS `coaching_recommendations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coaching_recommendations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_id` bigint unsigned NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Kategori pembinaan, misal: keuangan, pemasaran',
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci,
  `status` enum('pending','in_progress','done') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_by` bigint unsigned NOT NULL,
  `validated_by` bigint unsigned DEFAULT NULL,
  `validated_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `coaching_recommendations_created_by_foreign` (`created_by`),
  KEY `coaching_recommendations_validated_by_foreign` (`validated_by`),
  KEY `coaching_recommendations_evaluation_id_index` (`evaluation_id`),
  KEY `coaching_recommendations_status_index` (`status`),
  CONSTRAINT `coaching_recommendations_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `coaching_recommendations_evaluation_id_foreign` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `coaching_recommendations_validated_by_foreign` FOREIGN KEY (`validated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coaching_recommendations`
--

LOCK TABLES `coaching_recommendations` WRITE;
/*!40000 ALTER TABLE `coaching_recommendations` DISABLE KEYS */;
/*!40000 ALTER TABLE `coaching_recommendations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_details`
--

DROP TABLE IF EXISTS `evaluation_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluation_details` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `evaluation_id` bigint unsigned NOT NULL,
  `parameter_id` bigint unsigned NOT NULL,
  `indicator_id` bigint unsigned DEFAULT NULL,
  `numeric_value` decimal(15,2) DEFAULT NULL COMMENT 'Nilai input angka (misal: omzet)',
  `selected_value` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Nilai pilihan dari indikator select',
  `score` decimal(5,2) NOT NULL COMMENT 'Nilai skor 0-100 untuk parameter ini',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `evaluation_details_indicator_id_foreign` (`indicator_id`),
  KEY `evaluation_details_evaluation_id_index` (`evaluation_id`),
  KEY `evaluation_details_parameter_id_index` (`parameter_id`),
  CONSTRAINT `evaluation_details_evaluation_id_foreign` FOREIGN KEY (`evaluation_id`) REFERENCES `evaluations` (`id`) ON DELETE CASCADE,
  CONSTRAINT `evaluation_details_indicator_id_foreign` FOREIGN KEY (`indicator_id`) REFERENCES `evaluation_indicators` (`id`) ON DELETE SET NULL,
  CONSTRAINT `evaluation_details_parameter_id_foreign` FOREIGN KEY (`parameter_id`) REFERENCES `evaluation_parameters` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation_details`
--

LOCK TABLES `evaluation_details` WRITE;
/*!40000 ALTER TABLE `evaluation_details` DISABLE KEYS */;
INSERT INTO `evaluation_details` VALUES (1,1,1,NULL,NULL,NULL,88.00,'Kinerja sangat memuaskan dan disiplin syariah terjaga.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(2,1,2,NULL,NULL,NULL,88.00,'Kinerja sangat memuaskan dan disiplin syariah terjaga.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(3,1,3,NULL,NULL,NULL,88.00,'Kinerja sangat memuaskan dan disiplin syariah terjaga.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(4,1,4,NULL,NULL,NULL,88.00,'Kinerja sangat memuaskan dan disiplin syariah terjaga.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(5,1,5,NULL,NULL,NULL,88.00,'Kinerja sangat memuaskan dan disiplin syariah terjaga.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(6,2,1,NULL,NULL,NULL,72.00,'Omset cukup baik namun pencatatan keuangan manual masih perlu pendampingan.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(7,2,2,NULL,NULL,NULL,72.00,'Omset cukup baik namun pencatatan keuangan manual masih perlu pendampingan.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(8,2,3,NULL,NULL,NULL,72.00,'Omset cukup baik namun pencatatan keuangan manual masih perlu pendampingan.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(9,2,4,NULL,NULL,NULL,72.00,'Omset cukup baik namun pencatatan keuangan manual masih perlu pendampingan.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(10,2,5,NULL,NULL,NULL,72.00,'Omset cukup baik namun pencatatan keuangan manual masih perlu pendampingan.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(11,3,1,NULL,NULL,NULL,65.00,'Stok kain masih terbatas.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(12,3,2,NULL,NULL,NULL,65.00,'Stok kain masih terbatas.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(13,3,3,NULL,NULL,NULL,65.00,'Stok kain masih terbatas.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(14,3,4,NULL,NULL,NULL,65.00,'Stok kain masih terbatas.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(15,3,5,NULL,NULL,NULL,65.00,'Stok kain masih terbatas.','2026-10-04 17:33:43','2026-10-04 17:33:43');
/*!40000 ALTER TABLE `evaluation_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_indicators`
--

DROP TABLE IF EXISTS `evaluation_indicators`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluation_indicators` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `parameter_id` bigint unsigned NOT NULL,
  `code` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `scoring_type` enum('numeric','select','calculated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'numeric',
  `scoring_config` json DEFAULT NULL COMMENT 'Konfigurasi scoring: range, opsi, dll (OPEN ITEM)',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` tinyint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `evaluation_indicators_code_unique` (`code`),
  KEY `evaluation_indicators_parameter_id_index` (`parameter_id`),
  CONSTRAINT `evaluation_indicators_parameter_id_foreign` FOREIGN KEY (`parameter_id`) REFERENCES `evaluation_parameters` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation_indicators`
--

LOCK TABLES `evaluation_indicators` WRITE;
/*!40000 ALTER TABLE `evaluation_indicators` DISABLE KEYS */;
/*!40000 ALTER TABLE `evaluation_indicators` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluation_parameters`
--

DROP TABLE IF EXISTS `evaluation_parameters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluation_parameters` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Kode parameter, misal: kondisi_usaha',
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `weight` decimal(5,4) NOT NULL COMMENT 'Bobot 0.00-1.00, total harus = 1.00',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` tinyint unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `evaluation_parameters_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluation_parameters`
--

LOCK TABLES `evaluation_parameters` WRITE;
/*!40000 ALTER TABLE `evaluation_parameters` DISABLE KEYS */;
INSERT INTO `evaluation_parameters` VALUES (1,'kondisi_usaha','Kondisi Usaha',0.2000,1,1,'2026-10-04 17:33:43','2026-10-04 17:33:43'),(2,'perkembangan_omzet','Perkembangan Omzet',0.2500,1,2,'2026-10-04 17:33:43','2026-10-04 17:33:43'),(3,'aktivitas_usaha','Aktivitas Usaha',0.2000,1,3,'2026-10-04 17:33:43','2026-10-04 17:33:43'),(4,'pengelolaan_keuangan','Pengelolaan Keuangan',0.2000,1,4,'2026-10-04 17:33:43','2026-10-04 17:33:43'),(5,'kendala_usaha','Kendala Usaha',0.1500,1,5,'2026-10-04 17:33:43','2026-10-04 17:33:43');
/*!40000 ALTER TABLE `evaluation_parameters` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `evaluations`
--

DROP TABLE IF EXISTS `evaluations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `evaluations` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `visit_id` bigint unsigned NOT NULL,
  `business_id` bigint unsigned NOT NULL,
  `status` enum('draft','waiting_validation','validated','rejected') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'draft',
  `total_score` decimal(5,2) DEFAULT NULL COMMENT 'Nilai akhir 0-100',
  `recommendation` enum('recommended','continued_coaching','not_recommended') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recommendation_reason` text COLLATE utf8mb4_unicode_ci,
  `submitted_by` bigint unsigned DEFAULT NULL,
  `validated_by` bigint unsigned DEFAULT NULL,
  `submitted_at` timestamp NULL DEFAULT NULL,
  `validated_at` timestamp NULL DEFAULT NULL,
  `validator_notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `evaluations_visit_id_unique` (`visit_id`),
  KEY `evaluations_submitted_by_foreign` (`submitted_by`),
  KEY `evaluations_validated_by_foreign` (`validated_by`),
  KEY `evaluations_business_id_index` (`business_id`),
  KEY `evaluations_status_index` (`status`),
  KEY `evaluations_recommendation_index` (`recommendation`),
  CONSTRAINT `evaluations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `evaluations_submitted_by_foreign` FOREIGN KEY (`submitted_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `evaluations_validated_by_foreign` FOREIGN KEY (`validated_by`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `evaluations_visit_id_foreign` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evaluations`
--

LOCK TABLES `evaluations` WRITE;
/*!40000 ALTER TABLE `evaluations` DISABLE KEYS */;
INSERT INTO `evaluations` VALUES (1,1,1,'validated',88.00,'recommended','Usaha anggota menunjukkan kinerja baik dengan total skor 0.00. Usaha memenuhi seluruh kriteria pembinaan.',3,1,'2026-09-20 17:33:43','2026-09-21 17:33:43','Hasil evaluasi sangat baik, pembukuan rapih, disetujui untuk peningkatan plafond pembiayaan.','2026-10-04 17:33:43','2026-10-04 17:33:43'),(2,2,2,'waiting_validation',72.00,'continued_coaching','Usaha anggota memerlukan pembinaan lanjutan (skor: 0.00). Parameter \"Kondisi Usaha\" memerlukan perhatian khusus.',3,NULL,'2026-09-27 17:33:43',NULL,NULL,'2026-10-04 17:33:43','2026-10-04 17:33:43'),(3,3,3,'draft',65.00,'continued_coaching','Usaha anggota memerlukan pembinaan lanjutan (skor: 0.00). Parameter \"Kondisi Usaha\" memerlukan perhatian khusus.',NULL,NULL,NULL,NULL,NULL,'2026-10-04 17:33:43','2026-10-04 17:33:43');
/*!40000 ALTER TABLE `evaluations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `member_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Nomor anggota koperasi',
  `full_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `membership_status` enum('active','inactive','suspended') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `notes` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_member_number_unique` (`member_number`),
  KEY `members_membership_status_index` (`membership_status`),
  KEY `members_member_number_index` (`member_number`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (1,'BMI-2024-001','Hj. Siti Aminah','Jl. Raya Pasir Kaliki No. 45, Tangerang','081234567890','active','Anggota sejak Januari 2023, usaha sembako lancar.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(2,'BMI-2024-002','Ahmad Fauzi','Kp. Sukamaju RT 03/RW 02, Curug, Tangerang','081398765432','active','Anggota aktif, pengajuan pembiayaan untuk bengkel motor.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(3,'BMI-2024-003','Nurul Hidayati','Perum Griya Asri Blok B2 No. 12, Cikupa','085712345678','active','Pengrajin konveksi busana muslimah.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(4,'BMI-2024-004','Bambang Supriyanto','Jl. Merdeka Barat No. 88, Balaraja','087811223344','active','Peternak budidaya lele.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL);
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_10_04_145632_create_permission_tables',1),(5,'2026_10_04_150000_add_role_to_users_table',1),(6,'2026_10_04_150001_create_members_table',1),(7,'2026_10_04_150002_create_businesses_table',1),(8,'2026_10_04_150003_create_visits_table',1),(9,'2026_10_04_150004_create_visit_documents_table',1),(10,'2026_10_04_150005_create_evaluation_parameters_table',1),(11,'2026_10_04_150006_create_evaluation_indicators_table',1),(12,'2026_10_04_150007_create_evaluations_table',1),(13,'2026_10_04_150008_create_evaluation_details_table',1),(14,'2026_10_04_150009_create_coaching_recommendations_table',1),(15,'2026_10_04_150010_create_coaching_followups_table',1),(16,'2026_10_04_150011_create_audit_logs_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_permissions`
--

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `model_has_roles` (
  `role_id` bigint unsigned NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `model_has_roles`
--

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` bigint unsigned NOT NULL,
  `role_id` bigint unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_has_permissions`
--

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('petugas_lapangan','asisten_manajer','manajer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'petugas_lapangan',
  `status` enum('active','inactive') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Admin Manajer','admin','manajer','active','admin@bmi.sendr.web.id',NULL,'$2y$12$nKKGRwK7bKFmWNInl4OmBe3TGYhi1UMbiLx1usTghatEOyKOeHt4i',NULL,'2026-10-04 17:33:43','2026-10-04 17:40:39'),(2,'Asisten Manajer','asisten','asisten_manajer','active','asisten@koperasibmi.co.id',NULL,'$2y$12$4mrWm/.0PLZ10P3RUtuF4OxCN1oHyovMaPu2EPjZHxPTN1Frlatt2',NULL,'2026-10-04 17:33:43','2026-10-04 17:37:03'),(3,'Petugas Lapangan','anggota01','petugas_lapangan','active','anggota01@bmi.sendr.web.id',NULL,'$2y$12$q4HqvhXygjp4n0KeEFWsaez7dwUQjVqNryjMNecQJmKDZxPaHjvc.',NULL,'2026-10-04 17:33:43','2026-10-04 17:40:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visit_documents`
--

DROP TABLE IF EXISTS `visit_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visit_documents` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `visit_id` bigint unsigned NOT NULL,
  `file_path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `file_size` int unsigned NOT NULL COMMENT 'Ukuran file dalam bytes',
  `caption` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visit_documents_visit_id_index` (`visit_id`),
  CONSTRAINT `visit_documents_visit_id_foreign` FOREIGN KEY (`visit_id`) REFERENCES `visits` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visit_documents`
--

LOCK TABLES `visit_documents` WRITE;
/*!40000 ALTER TABLE `visit_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `visit_documents` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `visits`
--

DROP TABLE IF EXISTS `visits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `visits` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `business_id` bigint unsigned NOT NULL,
  `officer_id` bigint unsigned NOT NULL,
  `visit_date` date NOT NULL,
  `evaluation_period` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Format: YYYY-MM (bulan evaluasi)',
  `status` enum('scheduled','in_progress','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'scheduled',
  `field_notes` text COLLATE utf8mb4_unicode_ci COMMENT 'Catatan petugas lapangan',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `visits_business_id_index` (`business_id`),
  KEY `visits_officer_id_index` (`officer_id`),
  KEY `visits_visit_date_index` (`visit_date`),
  KEY `visits_evaluation_period_index` (`evaluation_period`),
  KEY `visits_status_index` (`status`),
  CONSTRAINT `visits_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `businesses` (`id`) ON DELETE CASCADE,
  CONSTRAINT `visits_officer_id_foreign` FOREIGN KEY (`officer_id`) REFERENCES `users` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `visits`
--

LOCK TABLES `visits` WRITE;
/*!40000 ALTER TABLE `visits` DISABLE KEYS */;
INSERT INTO `visits` VALUES (1,1,3,'2026-09-19','2026-10','completed','Pemeriksaan stok barang sembako, pencatatan kas masuk buku harian tertib.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(2,2,3,'2026-09-26','2026-10','completed','Kunjungan rutin, pelanggan servis harian mencapai 8-10 motor. Butuh pembinaan pencatatan stok oli.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(3,3,3,'2026-10-01','2026-10','completed','Pemeriksaan pesanan jilbab jelang musim liburan.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL),(4,4,3,'2026-10-06','2026-10','scheduled','Jadwal monitoring masa panen siklus ke-3 kolam lele.','2026-10-04 17:33:43','2026-10-04 17:33:43',NULL);
/*!40000 ALTER TABLE `visits` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-05  2:48:38
